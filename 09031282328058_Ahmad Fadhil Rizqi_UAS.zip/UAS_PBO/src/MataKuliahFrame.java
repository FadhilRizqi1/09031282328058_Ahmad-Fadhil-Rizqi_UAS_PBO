import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class MataKuliahFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField idField, namaField;

    public MataKuliahFrame() {
        setTitle("CRUD Mata Kuliah");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(20, 20, 100, 20);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(120, 20, 150, 20);
        idField.setEnabled(false);
        add(idField);

        JLabel namaLabel = new JLabel("Nama Mata Kuliah:");
        namaLabel.setBounds(20, 50, 150, 20);
        add(namaLabel);

        namaField = new JTextField();
        namaField.setBounds(170, 50, 150, 20);
        add(namaField);

        JButton addButton = new JButton("Tambah");
        addButton.setBounds(20, 90, 100, 30);
        add(addButton);

        JButton updateButton = new JButton("Update");
        updateButton.setBounds(130, 90, 100, 30);
        add(updateButton);

        JButton deleteButton = new JButton("Hapus");
        deleteButton.setBounds(240, 90, 100, 30);
        add(deleteButton);

        model = new DefaultTableModel(new String[]{"ID", "Nama Mata Kuliah"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 140, 550, 200);
        add(sp);

        loadData();

        addButton.addActionListener(e -> addMataKuliah());
        updateButton.addActionListener(e -> updateMataKuliah());
        deleteButton.addActionListener(e -> deleteMataKuliah());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                namaField.setText(model.getValueAt(row, 1).toString());
            }
        });
    }

    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM matakuliah")) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("idmk"), rs.getString("nama")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addMataKuliah() {
        String nama = namaField.getText();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO matakuliah (nama) VALUES (?)")) {
            pstmt.setString(1, nama);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateMataKuliah() {
        int id = Integer.parseInt(idField.getText());
        String nama = namaField.getText();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE matakuliah SET nama = ? WHERE idmk = ?")) {
            pstmt.setString(1, nama);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteMataKuliah() {
        int id = Integer.parseInt(idField.getText());
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM matakuliah WHERE idmk = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
