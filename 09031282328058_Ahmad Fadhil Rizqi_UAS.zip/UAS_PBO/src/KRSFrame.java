import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class KRSFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField idField, idMhsField, idMkField, semesterField, tahunAjaranField;

    public KRSFrame() {
        setTitle("CRUD KRS");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel idLabel = new JLabel("ID KRS:");
        idLabel.setBounds(20, 20, 100, 20);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(120, 20, 150, 20);
        idField.setEnabled(false);
        add(idField);

        JLabel idMhsLabel = new JLabel("ID Mahasiswa:");
        idMhsLabel.setBounds(20, 50, 100, 20);
        add(idMhsLabel);

        idMhsField = new JTextField();
        idMhsField.setBounds(120, 50, 150, 20);
        add(idMhsField);

        JLabel idMkLabel = new JLabel("ID Mata Kuliah:");
        idMkLabel.setBounds(20, 80, 100, 20);
        add(idMkLabel);

        idMkField = new JTextField();
        idMkField.setBounds(120, 80, 150, 20);
        add(idMkField);

        JLabel semesterLabel = new JLabel("Semester:");
        semesterLabel.setBounds(20, 110, 100, 20);
        add(semesterLabel);

        semesterField = new JTextField();
        semesterField.setBounds(120, 110, 150, 20);
        add(semesterField);

        JLabel tahunAjaranLabel = new JLabel("Tahun Ajaran:");
        tahunAjaranLabel.setBounds(20, 140, 100, 20);
        add(tahunAjaranLabel);

        tahunAjaranField = new JTextField();
        tahunAjaranField.setBounds(120, 140, 150, 20);
        add(tahunAjaranField);

        JButton addButton = new JButton("Tambah");
        addButton.setBounds(20, 180, 100, 30);
        add(addButton);

        JButton deleteButton = new JButton("Hapus");
        deleteButton.setBounds(130, 180, 100, 30);
        add(deleteButton);

        model = new DefaultTableModel(new String[]{"ID KRS", "ID Mahasiswa", "ID Mata Kuliah", "Semester", "Tahun Ajaran"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 230, 750, 200);
        add(sp);

        loadData();

        addButton.addActionListener(e -> addKRS());
        deleteButton.addActionListener(e -> deleteKRS());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                idMhsField.setText(model.getValueAt(row, 1).toString());
                idMkField.setText(model.getValueAt(row, 2).toString());
                semesterField.setText(model.getValueAt(row, 3).toString());
                tahunAjaranField.setText(model.getValueAt(row, 4).toString());
            }
        });
    }

    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM krs")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("idkrs"),
                        rs.getInt("idmhs"),
                        rs.getInt("idmk"),
                        rs.getInt("semester"),
                        rs.getString("tahunajaran")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addKRS() {
        int idMhs = Integer.parseInt(idMhsField.getText());
        int idMk = Integer.parseInt(idMkField.getText());
        int semester = Integer.parseInt(semesterField.getText());
        String tahunAjaran = tahunAjaranField.getText();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO krs (idmhs, idmk, semester, tahunajaran) VALUES (?, ?, ?, ?)")) {
            pstmt.setInt(1, idMhs);
            pstmt.setInt(2, idMk);
            pstmt.setInt(3, semester);
            pstmt.setString(4, tahunAjaran);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteKRS() {
        int id = Integer.parseInt(idField.getText());
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM krs WHERE idkrs = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
