import javax.swing.*;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("Main Menu");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JButton mahasiswaButton = new JButton("CRUD Mahasiswa");
        mahasiswaButton.setBounds(50, 30, 200, 30);
        add(mahasiswaButton);

        JButton matakuliahButton = new JButton("CRUD Mata Kuliah");
        matakuliahButton.setBounds(50, 70, 200, 30);
        add(matakuliahButton);

        JButton krsButton = new JButton("CRUD KRS");
        krsButton.setBounds(50, 110, 200, 30);
        add(krsButton);

        mahasiswaButton.addActionListener(e -> new MahasiswaFrame().setVisible(true));
        matakuliahButton.addActionListener(e -> new MataKuliahFrame().setVisible(true));
        krsButton.addActionListener(e -> new KRSFrame().setVisible(true));
    }

    public static void main(String[] args) {
        new MainMenu().setVisible(true);
    }
}
