import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class MahasiswaFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField namaField, nimField, idField;

    public MahasiswaFrame() {
        setTitle("CRUD Mahasiswa");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(20, 20, 100, 20);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(120, 20, 150, 20);
        idField.setEnabled(false);
        add(idField);

        JLabel namaLabel = new JLabel("Nama:");
        namaLabel.setBounds(20, 50, 100, 20);
        add(namaLabel);

        namaField = new JTextField();
        namaField.setBounds(120, 50, 150, 20);
        add(namaField);

        JLabel nimLabel = new JLabel("NIM:");
        nimLabel.setBounds(20, 80, 100, 20);
        add(nimLabel);

        nimField = new JTextField();
        nimField.setBounds(120, 80, 150, 20);
        add(nimField);

        JButton addButton = new JButton("Tambah");
        addButton.setBounds(20, 120, 100, 30);
        add(addButton);

        JButton updateButton = new JButton("Update");
        updateButton.setBounds(130, 120, 100, 30);
        add(updateButton);

        JButton deleteButton = new JButton("Hapus");
        deleteButton.setBounds(240, 120, 100, 30);
        add(deleteButton);

        model = new DefaultTableModel(new String[]{"ID", "Nama", "NIM"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 170, 550, 150);
        add(sp);

        loadData();

        addButton.addActionListener(e -> addMahasiswa());
        updateButton.addActionListener(e -> updateMahasiswa());
        deleteButton.addActionListener(e -> deleteMahasiswa());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                namaField.setText(model.getValueAt(row, 1).toString());
                nimField.setText(model.getValueAt(row, 2).toString());
            }
        });
    }

    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM mahasiswa")) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("idmhs"), rs.getString("nama"), rs.getString("nim")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addMahasiswa() {
        String nama = namaField.getText();
        String nim = nimField.getText();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO mahasiswa (nama, nim) VALUES (?, ?)")) {
            pstmt.setString(1, nama);
            pstmt.setString(2, nim);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateMahasiswa() {
        int id = Integer.parseInt(idField.getText());
        String nama = namaField.getText();
        String nim = nimField.getText();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE mahasiswa SET nama = ?, nim = ? WHERE idmhs = ?")) {
            pstmt.setString(1, nama);
            pstmt.setString(2, nim);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteMahasiswa() {
        int id = Integer.parseInt(idField.getText());
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM mahasiswa WHERE idmhs = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
